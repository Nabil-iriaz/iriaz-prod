import { Component, OnInit } from '@angular/core';
// Import qui va permettre de faire les Alert
import { AlertController } from '@ionic/angular';
import { ModalController} from '@ionic/angular'; 

@Component({
  selector: 'app-movie-description',
  templateUrl: './movie-description.page.html',
  styleUrls: ['./movie-description.page.scss'],
})
export class MovieDescriptionPage implements OnInit {

  // Ici on met les variables qu'on a declaré dans le TS de la page qui envoie les infos au modal 
  photo;
  titre;
  nomGenre;
  date_sortie;
  duree;
  nom_realisateur;
  prenom_realisateur;
  synopsis;
  bande_annonce;
  origine;
  acteurs; 

  // Variables qui va me permettre de déterminer si le Film est vu ou pas
  boolean = false;
  nbreDeFois:number = 1;

  nonVu = "Pas encore vu";
  vuXFois = "Vous avez vu";


  constructor(public alertController: AlertController, public modalController: ModalController) { }
  
  ngOnInit() {
  }

  // Méthode qui permet tout simplement de fermer le Modal quand on clique sur Retour
  close() {
    this.modalController.dismiss();
  }

  // Quand on clique sur le bouton "Je l'ai vu", alors il est écrit qu'on a vu le Film et l'icone du bouton change
  jaiVu(){
    console.log("J'ai vu le film " + this.titre);
    this.boolean = true;
  }

  // Quand je clique sur le bouton + pour dire que j'ai encore vu le Film
  encoreVu(){
    // Si on a déjà vu au moins une fois le Film (en gros si on a déjà appuyé sur le bouton "Je l'ai vu")
    if(this.boolean === true){
      console.log("On ajoute +1 si l'utilisateur a vu encore une fois le Film");
      this.presentAlertAdd();
    }else{
      console.log("Je ne peux pas appuyé sur le bouton +1 car je n'ai pas vu le Film avant");
      this.presentAlertFalse();
    }
  }



  // Je crée une méthode AlertAdd, qui lorsque j'ai revu un Film me permet de dire que je l'ai revu plusieurs fois
  async presentAlertAdd() {
    const alert = await this.alertController.create({
      message: 'Avez-vous revu le film ' + this.titre + ' ?',
      buttons: [{
        text: 'Non',
        role: 'cancel',
        handler: () => {
          console.log("J'appuie sur le bouton Non, car je ne suis pas sûr d'avoir revu ce Film (j'ai encore une chance de refuser)");
        }
      },
      {
        text:'Oui',
        handler:() => {
          console.log("J'appuie sur le bouton Oui, cela doit m'ajouter +1 fois le Film vu");
          // Variable sum qui fait la somme du nombre de fois que j'ai vu le Film + 1
          var sum = this.nbreDeFois + 1;
          this.nbreDeFois = sum;
          //console.log(sum);
          //console.log(this.nbreDeFois);
          this.vuXFois = "Vous avez vu " + this.nbreDeFois + " fois le film";
        }
      }
    ]
    });

    await alert.present();
  }


  // Je crée une méthode AlertFalse, qui lorsque j'appuie sur le bouton + SANS vu le Film me dit que l'on doit voir le Film avant
  async presentAlertFalse() {
    const alert = await this.alertController.create({
      subHeader: 'Vous devez avoir vu au moins une fois le film ' + this.titre + ' avant de pouvoir accéder à cette fonctionnalité',
      buttons: [{
        text: 'OK',
        role: 'cancel',
        handler: () => {
          console.log("J'appuie sur le bouton OK, j'ai compris qu'il fallait que je regarde le Film avant");
        }
      }]
    });

    await alert.present();
  }


  // Lorsque j'appuie sur le bouton ( "croix rouge" )
  async presentAlertReinitialiser(){
    // On crée une constante objet qui va contenir les infos de l'Alert
    const alert = await this.alertController.create({
      header: 'Réinitialiser les données',
      message: 'Êtes vous sûr de ne jamais avoir vu le film ' + this.titre + " ?",
      buttons: [
        {
          text: 'Retour',
          // Quand je met un rôle cancel, alors même si je quitte l'Alert en appuyant en dehors du cadre, alors ca va me faire un "backdrop" et ca va quand même appeler le "handler"
          role: 'cancel',
          handler: () => {
            console.log("J'ai appuyé sur Retour, je ne prend pas en compte la réinitialisation");
          }
        },
        {
          text: 'Oui',
          handler: () => {
            console.log("J'ai appuyé sur Oui, la réinitialisation a été faite");
            this.boolean = false;
            this.nbreDeFois = 1;
            /* Je rajoute cette ligne car quand je réinitialise, j'avais appuyé sur le +1 auparavant donc "vuXFois" a conservé la valeur (ex: Vous avez vu 2 fois le film...),
               donc quand j'appuyais sur le bouton "Je l'ai vu", la valeur "vuXFois" prenait la valeur de l'exemple. Il fallait donc réinitialiser la valeur
               "vuXFois" à (ex: Vous avez vu...) */
            this.vuXFois = "Vous avez vu " + this.titre;
          }
        }
      ]
    });

    // Cela permet d'appeler l'Alert et donc de l'afficher
    await alert.present();
  }
}
