import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MovieDescriptionPage } from './movie-description.page';

const routes: Routes = [
  {
    path: '',
    component: MovieDescriptionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MovieDescriptionPageRoutingModule {}
