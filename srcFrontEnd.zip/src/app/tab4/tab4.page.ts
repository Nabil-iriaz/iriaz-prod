import { Component, OnInit } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-tab5',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
})
export class Tab4Page implements OnInit {


  constructor(public http: HttpClient) {

  }

  ngOnInit() {
  }

  boolean = false;
  showS1: boolean = false
  showS2: boolean = false

  invertBtn1(){
    this.showS1 = !this.showS1
  }
  invertBtn2(){
    this.showS2 = !this.showS2
  }

  // Lorsque l'on clique sur la checkbox et qu'on dit qu'on a vu toute la saison, alors toutes les checkbox s'activent
  vuSaison(){
    this.boolean = true;
  }


  /* Méthode qui va permettre de lire les données d'une URL de l'API ( les prendres ), http va prendre en compte toutes les données, et get
     va prendre ces données grâce à l'url donnée */
  readApi(url: string){
    return this.http.get(url);
  }

}

