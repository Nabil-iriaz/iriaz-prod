import { Component } from '@angular/core';
/* On importe le module HTTP qui va nous permettre de récuperer des films ou des séries sur une API
   Ici, on le met dans le time script de tab3, car c'est sur cette page que nous allons afficher les séries et films */
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ModalController} from '@ionic/angular';  // On utilise le Modal qui est une fonctionnalité Ioni qui facilite la Navigation
// On importe MovieDescriptionPage car lorsque l'on va cliqué sur la Vignette, on devra aller vers movie-description
import { MovieDescriptionPage } from './../movie-description/movie-description.page'; 

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  // On va créer des variables

  // On va crée un boulean à False, et dès que l'on appuie sur la loupe pour chercher le Film, il va se mettre à True
  boolean = false;

  // Variable quand la personne va entrer un titre, on va le stocker directement
  rechercheTitre = "";

  // Cette variable va nous permettre de stocker différentes informations du film
  movieData = {
    photo: "",
    titre: "",
    listeGenres: [],
    date_sortie: "",
    duree: "",
    nom_realisateur: "",
    prenom_realisateur: "",
    synopsis: "",
    bande_annonce: "",
    origine: "",
    listeActeurs: []
  }


  constructor(public http: HttpClient, public modalController: ModalController) {

  }

  
  /* Il s'agit là de l'utilisation du Modal, quand on appuie sur la vignette d'un Film, cette méthode est appelé, la méthode
     récupère toutes les variables que l'on a besoin avec l'URL, pour les envoyé vers MovieDescriptionPage qui prend en charge la 
     page movie-description */
  async openMovie() {
    const modal = await this.modalController.create({
      component: MovieDescriptionPage,
      componentProps:{
        // Ici je met les variables que j'ai besoin de récupérer pour les envoyer au Modal
        photo: this.movieData.photo,
        titre: this.movieData.titre,
        nomGenre: this.movieData.listeGenres,
        date_sortie: this.movieData.date_sortie,
        duree: this.movieData.duree,
        nom_realisateur: this.movieData.nom_realisateur,
        prenom_realisateur: this.movieData.prenom_realisateur,
        synopsis: this.movieData.synopsis,
        bande_annonce: this.movieData.bande_annonce,  
        origine: this.movieData.origine,
        acteurs: this.movieData.listeActeurs  
      }
    });
    return await modal.present();
  }


  // Méthode doRefresh, elle va rafraichir la page au début, et le setTimeout va correspondre à ce qu'il va se passer à la fin du rafraichissement
  doRefresh(event) {
    console.log('Début du Rafraichissement');

    setTimeout(() => {
      console.log('Fin du Rafraichissement');
      // Le boolean vaut false, ce qui va permettre de supprimer la Vignette
      this.boolean = false;
      // On remet la variable rechercheTitre à vide pour que la barre de recherche soit vide
      this.rechercheTitre = "";
      event.target.complete();
    }, 2000);
  }

  ngOnInit() {
  }


  /* Méthode qui va permettre de lire les données d'une URL de l'API ( les prendres ), http va prendre en compte toutes les données, et get
     va prendre ces données grâce à l'url donnée */
  readApi(url: string){
    return this.http.get(url);
  }


  /* 
     La maintenant qu'on peut récupérer le nom d'un film et qu'on l'a initié avec des caractères spéciaux si il y a des espaces, alors on a
     juste à copier coller tout le code qu'on a fait dans la méthode rechercheFilm, et c'est le même principe :
        - J'ai accès au nom du film et l'URL le comprend
        - La méthode readApi va me permettre de prendre les données du film que j'ai tappé, en effet on prend l'URL de base
          et on ajoute le nom du film grâce à une concaténation
        - Avec .subscribe, je m'abonne aux données et je peux afficher toutes les données du film
        - J'attribue ces données aux variables que j'ai créer précedemment
        - J'affiche ces variables dans mon code HTML et le tour est jouer
  */


  // Méthode qui va nous permettre de rechercher un film quand on va appuyé sur le bouton recherche
  /* Ici, on crée une constante recherche, car quand on recherche un film ou il y a des espaces, l'url ne le comprend pas, il doit ajouter
     des caractères spéciaux et c'est ce qu'on fait grâce à la méthode encodeURIComponent() et la méthode trim() qui remplace les espaces
     contre des caractères spéciaux */
  rechercheFilm(){
    console.log("Recherche du film " + this.rechercheTitre);
    const recherche = encodeURIComponent(this.rechercheTitre).trim();
    console.log("Recherche du film " + recherche);


    // POUR AVOIR ACCES A TOUTES LES DONNEES DU FILM


    /* On prend grâce à http les données de l'URL, en gros http va permettre d'avoir accès à l'URL et readApi va prendre toutes les données de 
       l'URL et va les lire */
      this.readApi('http://localhost:8080/film/' + recherche)

    /* On va s'abonner avec subscribe au résultat de cette fonction, càd qu'on va avoir accès à toutes les données que retourne la méthode 
       readAPI */
    // On va donc pouvoir "voir" les données en renvoyer l'objet "data" qui correspond à toutes les données de l'URL
    .subscribe((dataRecherche) => {
      // J'affiche dans la console toutes les données
      console.log(dataRecherche);

      // Je peux donc affecter toutes mes infos à chaque variables
      this.movieData.photo = dataRecherche[0].photo;
      this.movieData.titre = dataRecherche[0].titre;
      this.movieData.date_sortie = dataRecherche[0].date_sortie;
      this.movieData.duree = dataRecherche[0].duree_film;
      this.movieData.nom_realisateur = dataRecherche[0].nom_realisateur;
      this.movieData.prenom_realisateur = dataRecherche[0].prenom_realisateur;
      this.movieData.synopsis = dataRecherche[0].synopsis;
      this.movieData.bande_annonce = dataRecherche[0].bande_annonce;
      this.movieData.origine = dataRecherche[0].origine;


      // On a appuyé sur la loupe pour rechercher le Film, on met donc le boolean a True pour pouvoir afficher le contenu
      this.boolean = true;
    })



    // POUR AVOIR ACCES A TOUS LES GENRES DU FILM


    /* On prend grâce à http les données de l'URL, en gros http va permettre d'avoir accès à l'URL et readApi va prendre toutes les données de 
       l'URL et va les lire */
    this.readApi('http://localhost:8080/film/' + recherche + '/genres')


    /* On va s'abonner avec subscribe au résultat de cette fonction, càd qu'on va avoir accès à toutes les données que retourne la méthode 
      readAPI */
    // On va donc pouvoir "voir" les données en renvoyer l'objet "data" qui correspond à toutes les données de l'URL
    .subscribe((dataRechercheGenres) => {
      // J'affiche dans la console toutes les données
      console.log(dataRechercheGenres);
 
      // Je remet le Tableau de liste de Genre à vide, car quand on fait une nouvelle recherche les anciens genres se conservait
      this.movieData.listeGenres = [];
      // Pour récupérer la liste des Genres 
      for(var i=0; i<dataRechercheGenres.length; i++){
        this.movieData.listeGenres.push(dataRechercheGenres[i].nom_genre);
        //console.log(this.movieData.listeGenre[i]);
      }
      console.log(this.movieData.listeGenres);
        
     })



    // POUR AVOIR ACCES A TOUS LES ACTEURS DU FILM


    /* On prend grâce à http les données de l'URL, en gros http va permettre d'avoir accès à l'URL et readApi va prendre toutes les données de 
       l'URL et va les lire */
    this.readApi('http://localhost:8080/film/' + recherche + '/acteurs')


      /* On va s'abonner avec subscribe au résultat de cette fonction, càd qu'on va avoir accès à toutes les données que retourne la méthode 
       readAPI */
    // On va donc pouvoir "voir" les données en renvoyer l'objet "data" qui correspond à toutes les données de l'URL
    .subscribe((dataRechercheActeurs) => {
      // J'affiche dans la console toutes les données
      console.log(dataRechercheActeurs);

      // Je remet le Tableau de liste de Genre à vide, car quand on fait une nouvelle recherche les anciens genres se conservait
      this.movieData.listeActeurs = [];
      // Pour récupérer la liste des Genres 
      for(var i=0; i<dataRechercheActeurs.length; i++){
        this.movieData.listeActeurs.push(dataRechercheActeurs[i].prenom + ' ' + dataRechercheActeurs[i].nom);
        //console.log(this.movieData.listeGenre[i]);
      }
      console.log(this.movieData.listeActeurs);
 
    })

  }
}


