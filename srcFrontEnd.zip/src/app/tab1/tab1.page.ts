import { Component } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})

export class Tab1Page {

  // La je crée une variable photosFilmsList qui va contenir la liste de toutes mes photos (on remplira la liste quand on parcourera les données ), pareil pour Séries
  photosFilmsList: any;
  photosSeriesList: any;
 
  constructor(public http : HttpClient) {
    

    // POUR LES FILMS

    /* On prend grâce à http les données de l'url, en gros http va permettre d'aller sur Internet et readApi va prendre toutes les données de 
       l'url sur Internet */
    this.readApi('http://localhost:8080/user/5filmsVus')

    /* On va s'abonner avec subscribe au résultat de cette fonction, càd qu'on va avoir accès à toutes les données que retourne la méthode 
       readAPI */
    // On va donc pouvoir "voir" les données en renvoyer l'objet "data" qui correspond à toutes les données de l'url
    .subscribe((dataFilms) => {
      // J'affiche dans la console toutes les données
      //console.log(dataFilm);
 
      // Je dis tout simplement que ma variable créer avant va être égale au data de l'URL que j'ai lu
      this.photosFilmsList = dataFilms;

      // On voit bien que ma liste contient bien toutes mes photos
      console.log(this.photosFilmsList);
    })


    // POUR LES SERIES

    // Je procède de la même manière que pour Films
    this.readApi('http://localhost:8080/user/5seriesVues')

    .subscribe((dataSeries) => {
      // J'affiche toutes les données des Séries grâce à l'URL
      //console.log(dataSeries);

      this.photosSeriesList = dataSeries;
      console.log(this.photosSeriesList);
    })

  }

  /* Méthode qui va permettre de lire les données d'une URL de l'API ( les prendres ), http va prendre en compte toutes les données, et get
     va prendre ces données grâce à l'url donnée */
  readApi(URL: string){
    return this.http.get(URL);
  }


}
