import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FilmsVusPageRoutingModule } from './films-vus-routing.module';

import { FilmsVusPage } from './films-vus.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FilmsVusPageRoutingModule
  ],
  declarations: [FilmsVusPage]
})
export class FilmsVusPageModule {}
